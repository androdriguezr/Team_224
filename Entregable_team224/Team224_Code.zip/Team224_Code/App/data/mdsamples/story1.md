Actualmente, en las áreas de adquisición de talento en las empresas se está viendo un incremento en la utilización de recursos tanto económicos como humanos en el proceso de reclutamiento, selección y permanencia en vacantes de atención al cliente.

En las Instituciones Prestadoras de Servicios de Salud (IPS), para dar inicio al proceso de prestación de cualquier servicio es necesario que el usuario pase primero por empleados que realizan atención al público presencial y telefónica (en la empresa objeto de estudio se conocen como gestores de salud), por tal motivo son cargos indispensables.

Asimismo son de alta rotación y el proceso de selección debe ser lo más óptimo posible para garantizar en la medida de lo posible altos niveles de productividad.